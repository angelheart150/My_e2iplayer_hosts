import sys
path = '/usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer'	
sys.path.append(path) 
