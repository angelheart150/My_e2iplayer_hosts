# -*- coding: utf-8 -*-
###################################################
#  TorrentEZTV Host for E2iPlayer (EZTV + TorrServer)
#  Compatible with Python 2.7 / 3.x
#  Last modified: 29/10/2025 - popking (odem2014)
#  Last Update: 10/04/2026 - angel-heart (Mohamed Elsafty)
###################################################
# localization library
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
# host main class
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
# tools - write on log, write exception infos and merge dicts
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, E2ColoR
# add metadata to url
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
# library for json (instead of standard json.loads and json.dumps)
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
# read informations in m3u8
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
###################################################
from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import urljoin
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
from Components.config import config, ConfigSubsection, ConfigText
###################################################
# FOREIGN import
###################################################
import re
import time
import os
import socket
###################################################
# Constants
###################################################
C = E2ColoR("cyan")
L = E2ColoR("lime")
O = E2ColoR("orange")
R = E2ColoR("red")
W = E2ColoR("white")
Y = E2ColoR("yellow")
###################################################
# CONFIG SECTION
###################################################
config.plugins.iptvplayer.torserver = ConfigSubsection()
config.plugins.iptvplayer.torserver_ip = ConfigText(default="127.0.0.1", fixed_size=False)
config.plugins.iptvplayer.torserver_port = ConfigText(default="8090", fixed_size=False)
config.plugins.iptvplayer.torserver_api = ConfigText(default="", fixed_size=False)  # Changed default to empty
config.plugins.iptvplayer.torserver_path = ConfigText(default="/media/hdd/TorrServer", fixed_size=False)
config.plugins.iptvplayer.torserver_config = ConfigText(default="/media/hdd/config", fixed_size=False)
def GetConfigList():
    """Show TorServer config in E2iPlayer settings."""
    from Components.config import getConfigListEntry
    optionList = []
    optionList.append(getConfigListEntry(_("TorServer IP (default 127.0.0.1)"), config.plugins.iptvplayer.torserver_ip))
    optionList.append(getConfigListEntry(_("TorServer Port (default 8090)"), config.plugins.iptvplayer.torserver_port))
    optionList.append(getConfigListEntry(_("TorServer API path (usually empty)"), config.plugins.iptvplayer.torserver_api))  # Updated description
    optionList.append(getConfigListEntry(_("TorServer Binary Path"), config.plugins.iptvplayer.torserver_path))
    optionList.append(getConfigListEntry(_("TorServer Config Path"), config.plugins.iptvplayer.torserver_config))
    return optionList
def gettytul():
    return 'https://eztvx.to/'  # main url of host
###################################################
# MAIN HOST CLASS
###################################################
class TorrentEZTVHost(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'eztv.torrent', 'cookie': 'eztv.cookie'})
        self.MAIN_URL = gettytul()
        self.SEARCH_URL = self.MAIN_URL + '/search/'
        # --- TorrServer Configuration ---
        self.TORSERVER_PORT = 8090
        self.TORSERVER_IP = "127.0.0.1"
        self.TORSERVER_PATH = "/media/hdd/TorrServer"
        self.TORSERVER_CONFIG = "/media/hdd/config"
        self.DEFAULT_ICON_URL = 'https://raw.githubusercontent.com/popking159/mye2iplayer/refs/heads/main/torrenteztv.jpg'
        self.updateTorServerUrl()
        self.defaultParams = {
            'header': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'Accept-Language': 'en,ar;q=0.9',
                'Accept-Encoding': 'gzip, deflate',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
                'Upgrade-Insecure-Requests': '1',
                'Referer': self.MAIN_URL,
                'Origin': self.MAIN_URL.rstrip('/'),
                'Connection': 'keep-alive',
            },
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': True,
            'cookiefile': self.COOKIE_FILE
        }
    def updateTorServerUrl(self):
        ip = config.plugins.iptvplayer.torserver_ip.value.strip()
        port = config.plugins.iptvplayer.torserver_port.value.strip()
        api = config.plugins.iptvplayer.torserver_api.value.strip()
        # Build base URL without API path for endpoints
        if api:
            self.TORSERVER_BASE = 'http://%s:%s/%s' % (ip, port, api.rstrip('/'))
        else:
            self.TORSERVER_BASE = 'http://%s:%s' % (ip, port)
        printDBG("TorServer base URL: %s" % self.TORSERVER_BASE)
    def isPortOpen(self, host, port, timeout=1.0):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            return result == 0
        except Exception as e:
            printDBG("isPortOpen error: %s" % str(e))
            return False
    def ensureTorServerRunning(self):
        """
        Ensure TorrServer is running and listening.
        If already running, restart cleanly.
        """
        port = int(config.plugins.iptvplayer.torserver_port.value.strip() or "8090")
        ip = config.plugins.iptvplayer.torserver_ip.value.strip() or "127.0.0.1"
        binary = config.plugins.iptvplayer.torserver_path.value.strip()
        config_path = config.plugins.iptvplayer.torserver_config.value.strip()
        # Check if config directory exists, create it if it doesn't
        if config_path and not os.path.exists(config_path):
            printDBG("Config directory does not exist, creating: %s" % config_path)
            try:
                os.makedirs(config_path, mode=0o755)  # Create directory with read/write/execute permissions for owner, read/execute for group/others
                printDBG("Successfully created config directory: %s" % config_path)
            except Exception as e:
                printDBG("Failed to create config directory %s: %s" % (config_path, str(e)))
                # Continue anyway, TorrServer might create it or use default locations
        # Check if port is already in use
        running = self.isPortOpen(ip, port)
        # If running, stop it first
        if running:
            printDBG("TorServer already running at %s:%s — restarting..." % (ip, port))
            try:
                shutdown_url = "http://%s:%s/shutdown" % (ip, port)
                self.cm.getPage(shutdown_url)
                time.sleep(2)
            except Exception as e:
                printDBG("Failed to shutdown old instance: %s" % e)
        # Start TorrServer fresh
        try:
            if binary and os.path.exists(binary):
                cmd = "%s -path %s -port %d > /dev/null 2>&1 &" % (binary, config_path, port)
                printDBG("Starting TorServer binary: %s" % cmd)
                os.system(cmd)
                time.sleep(4)
            else:
                printDBG("TorServer binary not found at: %s" % binary)
                return False
        except Exception as e:
            printDBG("Failed to start TorServer: %s" % e)
            return False
        # Verify it's up
        running = self.isPortOpen(ip, port, timeout=3.0)
        if running:
            printDBG("TorServer started successfully on %s:%d" % (ip, port))
        else:
            printDBG("TorServer failed to start on %s:%d" % (ip, port))
        return running
    def getPage(self, url, params=None, post_data=None):
        """Wrapper for getPage with Cloudflare protection - SAME AS YTS"""
        if params is None:
            params = dict(self.defaultParams)
        # Update dynamic headers
        params['header']['Referer'] = self.MAIN_URL
        params['header']['Origin'] = self.MAIN_URL.rstrip('/')
        params['cloudflare_params'] = {
            'cookie_file': self.COOKIE_FILE,
            'User-Agent': params['header']['User-Agent']
        }
        return self.cm.getPageCFProtection(url, params, post_data)
    ###################################################
    # LISTING
    ###################################################
    def listMainMenu(self, cItem):
        printDBG('TorrentEZTVHost.listMainMenu')
        MAIN_CAT_TAB = [
            {'category': 'list_movies', 'title': _('Series'), 'url': self.getFullUrl('/home')},
        ] + self.searchItems()
        self.listsTab(MAIN_CAT_TAB, cItem)
    ###################################################
    # LIST MOVIES/SERIES
    ###################################################
    def listMovies(self, cItem):
        printDBG("TorrentEZTVHost.listMovies url[%s]" % cItem.get('url', ''))
        sts, data = self.getPage(cItem.get('url', ''))
        if not sts or not data:
            return
        try:
            main_block_series = self.cm.ph.getAllItemsBeetwenMarkers(data, '<tr class="forum_space_border">', '</table>', False)[0]
        except Exception:
            main_block_series = data
        items = self.cm.ph.getAllItemsBeetwenMarkers(main_block_series, '<tr name="hover"', '</tr>', False)
        printDBG("Found %d serie items" % len(items))
        for item in items:
            try:
                # --- Extract episode URLs (/ep/...)
                url = self.cm.ph.getSearchGroups(item, r'href="(/ep/[^"]+)"')[0]
                if not url:
                    continue
                full_url = self.MAIN_URL + url.lstrip('/') if not url.startswith('http') else url
                # --- Extract title
                title = self.cm.ph.getSearchGroups(item, r'class="epinfo"[^>]*>([^<]+)<')[0].strip()
                if not title:
                    title = self.cm.ph.getSearchGroups(item, r'title="([^"]+)"')[0].strip()
                if not title:
                    continue
                # --- Extract size and age
                size = self.cm.ph.getSearchGroups(item, r'<td[^>]*>([\d\.]+\s*[MGK]B)</td>')[0].strip() or 'Unknown'
                added_ago = self.cm.ph.getSearchGroups(item, r'<td[^>]*>(\d+\s*[smhdwy])</td>')[0].strip() or 'Unknown'
                seeds = self.cm.ph.getSearchGroups(item, r'<font[^>]*>(\d+)</font>')[0].strip() or '0'
                # --- COLORIZATION ---
                short_title = re.split(r'\b(480p|720p|1080p|2160p|x264|x265|h\.?264|h\.?265|hevc|xvid|WEB|HDTV|BluRay)\b', title, 1, flags=re.I)[0]
                short_title = short_title.strip().rstrip('-').strip()
                def safe_sub(pattern, color, text, flags=0):
                    try:
                        return re.sub(pattern,
                                      lambda m: E2ColoR(color) + m.group(0) + W,
                                      text, flags=flags)
                    except:
                        return text
                color_title = title
                # 1-Colorize show tag [eztv]
                color_title = safe_sub(r'\[eztv\]', 'khaki', color_title, re.I)
                # 2-Resolution (480p, 720p, 1080p, 2160p)
                color_title = safe_sub(r'\b(480p|720p|1080p|2160p)\b', 'fuchsia', color_title, re.I)
                # 3-Codec formats (x264, x265, h264, hevc, xvid)
                color_title = safe_sub(r'\b(x264|x265|h\.?264|h\.?265|hevc|xvid)\b', 'olive', color_title, re.I)
                # 4-Source tags (WEB, WEBRip, WEB-DL, HDTV, BluRay)
                color_title = safe_sub(r'\b(WEB[- ]?DL|WEB[- ]?Rip|WEB|HDTV|BluRay|DVDRip|CAM|TS)\b', 'aqua', color_title, re.I)
                # 5-Release group (after a dash, e.g. -FENiX)
                color_title = safe_sub(r'-(\w+)$', 'violet', color_title, re.I)
                # 6-Season/Episode combined (S01E05)
                color_title = safe_sub(r'\bS\d{1,2}E\d{1,2}\b', 'yellow', color_title, re.I)
                # 7-Individual season or episode (S01, E05)
                color_title = safe_sub(r'\bS\d{1,2}\b', 'green', color_title, re.I)
                color_title = safe_sub(r'\bE\d{1,2}\b', 'yellow', color_title, re.I)
                # 8-Year patterns
                color_title = safe_sub(r'\b(19\d{2}|20\d{2})\b', 'orange', color_title)
                # --- Description
                desc = (
                    "Size: " + Y + size + W +
                    " | Added: " + C + added_ago + W +
                    " | Seeds: " + O + seeds + W
                )
                # --- Add directory entry
                params = dict(cItem)
                params.update({
                    'title': color_title,
                    'short_title': short_title,
                    'url': full_url,
                    'desc': desc,
                    'icon': self.DEFAULT_ICON_URL,
                    'category': 'movie_torrents',
                    "good_for_fav": True,
                })
                self.addDir(params)
            except Exception as e:
                printDBG("Error parsing item: %s" % str(e))
        # --- NEXT PAGE ---
        next_page = self.cm.ph.getSearchGroups(
            data, r'<a href="([^"]+)" title="EZTV Torrents - Page: \d+"> next page</a>'
        )[0]
        if next_page:
            if not next_page.startswith('http'):
                next_page = self.MAIN_URL + next_page.lstrip('/')
            params = dict(cItem)
            params.update({'title': _('Next Page »»»'), 'url': next_page})
            self.addDir(params)
    ###################################################
    # LIST TORRENTS FOR MOVIE
    ###################################################
    def exploreItems(self, cItem):
        printDBG("TorrentEZTVHost.exploreItems url[%s]" % cItem.get('url', ''))
        # 🔹 Get episode page
        sts, data = self.getPage(cItem.get('url', ''))
        if not sts or not data:
            printDBG("Failed to get episode page data")
            return
        # --------------------------------------------------
        # 🔹 Extract main sections from page
        # --------------------------------------------------
        main_section = self.cm.ph.getDataBeetwenMarkers(
            data, 'class="episode_left_column">',
            'class="section_post_header">Alternate Releases', False
        )[1]
        if not main_section:
            main_section = data
        # 🔹 Episode details section
        section1 = self.cm.ph.getDataBeetwenMarkers(
            main_section, 
            '<td class="section_post_header">Episode Breakdown</td>',
            '</table>', False
        )[1]
        # 🔹 Download links section
        section2 = self.cm.ph.getDataBeetwenMarkers(
            main_section,
            '<td class="section_post_header">Download Links</td>',
            '</table>', False
        )[1]
        # 🔹 Torrent info section
        section3 = self.cm.ph.getDataBeetwenMarkers(
            main_section,
            '<td class="section_post_header">Torrent Info</td>',
            '</table>', False
        )[1]
        # --------------------------------------------------
        # 🔹 Extract plot using background color marker
        # --------------------------------------------------
        plot_box = self.cm.ph.getDataBeetwenMarkers(
            data, 'background-color: #C8E2F9;', '</div>', False
        )[1]
        # 🔹 Remove leftover HTML
        if '>' in plot_box:
            plot = plot_box.split('>', 1)[-1]
        else:
            plot = plot_box
        plot = self.cleanHtmlStr(plot)
        # --------------------------------------------------
        # 🔹 Extract poster image
        # --------------------------------------------------
        poster = self.cm.ph.getSearchGroups(
            section1, r'<img[^>]+src="([^"]+)"'
        )[0]
        if poster:
            # 🔹 Attach headers to bypass Cloudflare
            poster = strwithmeta(self.getFullUrl(poster), {
                'User-Agent': self.defaultParams['header']['User-Agent'],
                'Referer': self.MAIN_URL,
                'Cookie': self.cm.getCookieHeader(self.COOKIE_FILE)
            })
        else:
            poster = self.DEFAULT_ICON_URL
        # --------------------------------------------------
        # 🔹 Extract main details
        # --------------------------------------------------
        season = self.cm.ph.getSearchGroups(section1, r'<b>Season:</b>\s*(\d+)')[0]
        episode = self.cm.ph.getSearchGroups(section1, r'<b>Episode:</b>\s*(\d+)')[0]
        torrent_link = self.cm.ph.getSearchGroups(section2, r'href="(https?://[^"]+\.torrent)"')[0]
        magnet_link = self.cm.ph.getSearchGroups(section2, r'href="(magnet:[^"]+)"')[0]
        # 🔹 Full added text (time + uploader)
        added_text = self.cleanHtmlStr(
            self.cm.ph.getDataBeetwenMarkers(section2, 'Added', '</div>', False)[1]
        )
        # 🔹 Extract uploader name only
        uploader = self.cm.ph.getSearchGroups(
            section2, r'by\s*<span[^>]*>([^<]+)<'
        )[0]
        # 🔹 Torrent metadata
        torrent_hash = self.cm.ph.getSearchGroups(section3, r'<b>Torrent Hash:</b>\s*([^<]+)<')[0]
        file_size = self.cm.ph.getSearchGroups(section3, r'<b>Filesize:</b>\s*([^<]+)<')[0]
        released = self.cm.ph.getSearchGroups(section3, r'<b>Released:</b>\s*([^<]+)<')[0]
        resolution = self.cm.ph.getSearchGroups(section3, r'<b>Resolution:</b>\s*([^<]+)<')[0]
        format_ = self.cm.ph.getSearchGroups(section3, r'<b>File Format:</b>\s*([^<]+)<')[0]
        # --------------------------------------------------
        # 🔹 Build colored description
        # --------------------------------------------------
        try:
            W, Y, C, R, O, V, B, G = [
                E2ColoR(c) for c in
                ['white','yellow','cyan','crimson','orange','violet','dodgerblue','gold']
            ]
        except:
            W = Y = C = R = O = V = B = G = ''
        desc_lines = []
        # 🔹 Line 1: Episode info
        line1 = []
        if season:    line1.append(Y + "Season: " + W + season)
        if episode:   line1.append(Y + "Episode: " + W + episode)
        if file_size: line1.append(C + "Size: " + W + file_size)
        if released:  line1.append(R + "Released: " + W + released)
        if resolution: line1.append(O + "Resolution: " + W + resolution)
        if line1:
            desc_lines.append(" | ".join(line1))
        # 🔹 Line 2: Extra info
        line2 = []
        if format_:    line2.append(V + "Format: " + W + format_)
        if added_text: line2.append(B + "Added: " + W + added_text)
        if uploader:   line2.append(G + "Uploader: " + W + uploader)
        if line2:
            desc_lines.append(" | ".join(line2))
        # 🔹 Line 3: Summary only if exists
        if plot and 'Summary' in data:
            desc_lines.append(L + "Summary: " + W + plot)
        full_desc = "\n".join(desc_lines).strip()
        # --------------------------------------------------
        # 🔹 Display items
        # --------------------------------------------------
        display_name = cItem.get('short_title', cItem['title'])
        # 🔹 Add torrent item
        if torrent_link:
            params = dict(cItem)
            params.update({
                'title': display_name + ' - ' + C + 'Torrent' + W,
                'url': torrent_link,
                'icon': poster,
                'desc': full_desc,
                'category': 'video'
            })
            self.addVideo(params)
        # 🔹 Add magnet item
        if magnet_link:
            params = dict(cItem)
            params.update({
                'title': display_name + ' - ' + O + 'Magnet' + W,
                'url': magnet_link,
                'icon': poster,
                'desc': full_desc,
                'category': 'video'
            })
            self.addVideo(params)
    ###################################################
    # SEARCH MOVIES
    ###################################################
    def searchMovies(self, pattern, cItem):
        if not pattern:
            pattern = self.searchPattern
        printDBG("TorrentEZTVHost.searchMovies pattern[%s]" % pattern)
        safe_pattern = urllib_quote_plus(pattern)
        search_url = '%ssearch/%s' % (self.MAIN_URL, safe_pattern)
        params = dict(cItem)
        params.update({'url': search_url, 'category': 'list_movies'})
        self.listMovies(params)
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("TorrentEZTVHost.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        cItem = dict(cItem)
        cItem['url'] = self.SEARCH_URL + urllib_quote_plus(searchPattern)
        self.listMovies(cItem)
    ###################################################
    # PLAY TORRENT VIA TORSERVER - M3U GENERATION
    ###################################################
    def getLinksForVideo(self, cItem):
        self.updateTorServerUrl()
        # Check if TorServer is running
        ip = config.plugins.iptvplayer.torserver_ip.value.strip() or "127.0.0.1"
        port = int(config.plugins.iptvplayer.torserver_port.value.strip() or "8090")
        if not self.isPortOpen(ip, port, timeout=2.0):
            printDBG("TorServer not running, attempting to start...")
            if not self.ensureTorServerRunning():
                printDBG("TorServer could not be started.")
                return []
        torrent_url = cItem.get('url', '')
        if not torrent_url:
            printDBG("No torrent link found!")
            return []
        printDBG("Processing torrent URL: %s" % torrent_url)
        # URL encode the torrent URL
        encoded_url = urllib_quote_plus(torrent_url)
        # Use /stream/fname endpoint for stable single-file playback
        stream_url = "%s/stream/fname?link=%s&index=0&play=1&subtitles=1" % (self.TORSERVER_BASE, encoded_url)
        printDBG("Direct stream URL (fname mode): %s" % stream_url)
        # Add Enigma2 metadata for stable playback
        url_with_meta = strwithmeta(stream_url, {
            'iptv_proto': 'http_ts',
            'live': True,
            'buffering': '1',
            'Referer': self.TORSERVER_BASE,
            'User-Agent': 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36',
            'accept': 'video/x-matroska,application/octet-stream'
        })
        # Give TorrServer a short preload time
        time.sleep(1)
        return [{'name': 'TorServer Stream (Stable)', 'url': url_with_meta, 'need_resolve': 0}]
    def parseM3UContent(self, m3u_data, base_url):
        """Parse M3U content and extract stream URLs"""
        streams = []
        try:
            lines = m3u_data.split('\n')
            for line in lines:
                line = line.strip()
                # Look for actual stream URLs (not comments or metadata)
                if line and not line.startswith('#') and line.startswith('http'):
                    printDBG("Found stream URL in M3U: %s" % line)
                    # Create URL with metadata
                    stream_url = strwithmeta(line, {
                        'iptv_proto': 'http',
                        'Referer': base_url,
                        'User-Agent': 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36'
                    })
                    # Extract quality info from the line or use default
                    name = 'TorServer Stream'
                    if '720p' in line:
                        name = '720p Stream'
                    elif '1080p' in line:
                        name = '1080p Stream'
                    elif '480p' in line:
                        name = '480p Stream'
                    streams.append({'name': name, 'url': stream_url, 'need_resolve': 0})
            printDBG("Parsed %d streams from M3U" % len(streams))
        except Exception as e:
            printDBG("Error parsing M3U content: %s" % str(e))
            printExc()
        return streams
    def getVideoLinks(self, url):
        printDBG("TorrentEZTVHost.getVideoLinks [%s]" % url)
        urlTab = []
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return urlTab
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('TorrentEZTVHost.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: >> name[%s], category[%s] " % (name, category))
        self.currList = []
        # MAIN MENU
        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'movie_torrents':
            self.exploreItems(self.currItem)
        elif category == 'explore_items':
            self.exploreItems(self.currItem)
        elif category == 'list_movies':
            self.listMovies(self.currItem)
        elif category == 'series_categories':
            self.listSeriesCategories(self.currItem)
        elif category == 'list_series':
            self.listUnits(self.currItem)
        # SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        # HISTORY SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)
###################################################
# E2I WRAPPER
###################################################
class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, TorrentEZTVHost(), True, [])