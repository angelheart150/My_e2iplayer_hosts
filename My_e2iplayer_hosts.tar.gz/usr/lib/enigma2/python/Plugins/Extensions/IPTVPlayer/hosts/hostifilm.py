# -*- coding: utf-8 -*-
####################################################
# iFilm Arabic - host for E2iPlayer (py3)
# # # Developer: aim0005
####################################################

from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
import re
import urllib.parse

def gettytul():
    return 'https://ar.ifilmtv.ir/'

def GetConfigList():
    return []

class iFilmArabic(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'iFilmArabic.tv', 'cookie': 'ifilmarabic.cookie'})
        self.DEFAULT_ICON_URL = 'https://ar.ifilmtv.ir/img/final-logo01.png'
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        self.MAIN_URL = 'https://ar.ifilmtv.ir/'
        self.VIDEO_URL = 'https://video.ifilmtv.ir/'
        self.LIVE_URL = 'https://ar.ifilmtv.ir/Home/Live'
        
        # روابط البث المباشر - محدثة ديسمبر 2025
        self.STREAM_URLS = [
            ('البث المباشر - جودة عالية', 'https://live.presstv.ir/hls/ifilmar.m3u8'),
            ('البث المباشر - بديل 1', 'https://live2.presstv.com/ifilmlive/smil:ifilmar.smil/index.m3u8'),
        ]
        
        self.defaultParams = {
            'header': {
                'User-Agent': self.USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'ar,en;q=0.9',
                'Referer': self.MAIN_URL
            }
        }
        
        self.ITEMS_PER_PAGE = 18

    def getPage(self, baseUrl, addParams={}, post_data=None):
        if addParams == {}:
            addParams = dict(self.defaultParams)
        else:
            addParams = MergeDicts(self.defaultParams, addParams)
        return self.cm.getPage(baseUrl, addParams, post_data)

    def listMainMenu(self, cItem):
        printDBG('iFilmArabic.listMainMenu')
        
        self.addDir({
            'name': 'category',
            'category': 'live_streams',
            'title': '📺 البث المباشر',
            'icon': self.DEFAULT_ICON_URL,
            'desc': 'مشاهدة البث المباشر لقناة iFilm Arabic'
        })
        
        self.addDir({
            'name': 'category',
            'category': 'series_list',
            'title': '🎬 مسلسلات',
            'url': self.MAIN_URL + 'Series',
            'icon': self.DEFAULT_ICON_URL,
            'desc': 'مسلسلات قناة آي فيلم',
            'page': 1
        })
        
        self.addDir({
            'name': 'category',
            'category': 'films_list',
            'title': '🎥 أفلام',
            'url': self.MAIN_URL + 'Film',
            'icon': self.DEFAULT_ICON_URL,
            'desc': 'أفلام قناة آي فيلم',
            'page': 1
        })
        
        self.addDir({
            'name': 'category',
            'category': 'programs_list',
            'title': '📺 برامج',
            'url': self.MAIN_URL + 'Program',
            'icon': self.DEFAULT_ICON_URL,
            'desc': 'برامج قناة آي فيلم',
            'page': 1
        })
        
        self.addDir({
            'name': 'category',
            'category': 'search',
            'title': '🔍 بحث',
            'icon': self.DEFAULT_ICON_URL,
            'search_item': True,
            'desc': 'البحث في المسلسلات والأفلام والبرامج'
        })
        
        self.addDir({
            'name': 'category',
            'category': 'search_history',
            'title': '📜 سجل البحث',
            'icon': self.DEFAULT_ICON_URL,
            'desc': 'عرض سجل البحث السابق'
        })

    def listLiveStreams(self, cItem):
        printDBG('iFilmArabic.listLiveStreams')
        
        # محاولة جلب الرابط من الموقع الرسمي أولاً
        official_url = self._getStreamFromOfficialSite()
        if official_url:
            self.addVideo({
                'type': 'video',
                'title': '📺 البث المباشر - الموقع الرسمي',
                'url': official_url,
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'iFilm Arabic - البث المباشر من الموقع الرسمي'
            })
        
        # إضافة الروابط البديلة
        for title, url in self.STREAM_URLS:
            self.addVideo({
                'type': 'video',
                'title': title,
                'url': url,
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'iFilm Arabic - البث المباشر'
            })

    def _getStreamFromOfficialSite(self):
        printDBG('iFilmArabic._getStreamFromOfficialSite')
        try:
            sts, data = self.getPage(self.LIVE_URL)
            if not sts:
                return None
            
            patterns = [
                # الرابط المباشر في الصفحة (كما رأيناه)
                r'href=["\']?(https?://live[^"\'\s<>]+\.m3u8)["\'\s<>]',
                # srcjsplayer attribute (used by Plyr)
                r'srcjsplayer=["\']([^"\']+\.m3u8[^"\']*)["\']',
                # Standard src
                r'<source[^>]+src=["\']([^"\']+\.m3u8[^"\']*)["\']',
                # Generic URL in quotes
                r'["\'](https?://live[^\s"\']+\.m3u8[^\s"\']*)["\']',
                r'src=["\']([^"\']+\.m3u8[^"\']*)["\']',
                # الرابط في الأقواس
                r'\((https?://live[^)]+\.m3u8)\)',
            ]
            
            for pattern in patterns:
                match = re.search(pattern, data, re.IGNORECASE)
                if match:
                    url = match.group(1)
                    if url.startswith('//'):
                        url = 'https:' + url
                    printDBG('iFilmArabic: Found live stream URL: %s' % url)
                    return url
        except:
            printExc()
        return None

    # ==================== المسلسلات ====================
    
    def listSeriesList(self, cItem):
        printDBG('iFilmArabic.listSeriesList')
        
        page = cItem.get('page', 1)
        base_url = cItem.get('url', self.MAIN_URL + 'Series')
        
        if page > 1:
            url = '%s?order=1&page=%d' % (base_url.split('?')[0], page)
        else:
            url = base_url
        
        sts, data = self.getPage(url)
        if not sts:
            printDBG('iFilmArabic: Failed to get series page')
            return
        
        items = self._parseContentList(data, 'series')
        printDBG('iFilmArabic: Found %d series' % len(items))
        
        for item in items:
            self.addDir({
                'name': 'category',
                'category': 'series_episodes',
                'title': item['title'],
                'url': item['url'],
                'icon': item['icon'],
                'desc': item.get('desc', ''),
            })
        
        if len(items) >= self.ITEMS_PER_PAGE:
            self.addDir({
                'name': 'category',
                'category': 'series_list',
                'title': '⬅️ الصفحة التالية (%d)' % (page + 1),
                'url': base_url,
                'icon': self.DEFAULT_ICON_URL,
                'page': page + 1
            })

    def listSeriesEpisodes(self, cItem):
        printDBG('iFilmArabic.listSeriesEpisodes url: %s' % cItem.get('url', ''))
        
        url = cItem.get('url', '').rstrip('?')
        if not url:
            return
        
        # استخراج معرف المحتوى من الرابط
        content_id = None
        match = re.search(r'/Content/(\d+)', url)
        if match:
            content_id = match.group(1)
        
        sts, data = self.getPage(url)
        if not sts:
            return
        
        series_title = cItem.get('title', '')
        desc = self._extractDescription(data)
        poster = self._extractPoster(data)
        icon = poster if poster else cItem.get('icon', self.DEFAULT_ICON_URL)
        
        episodes = []
        
        # الطريقة الرئيسية: استخراج من JavaScript في الصفحة
        # البحث عن: var inter_ = XX; (عدد الحلقات)
        # و var ID_Serial = XXXXX;
        episodes = self._extractEpisodesFromJS(data, content_id)
        
        # الطريقة البديلة: API
        if not episodes and content_id:
            episodes = self._getEpisodesFromAPI(content_id)
        
        # الطريقة الثالثة: البحث عن روابط mp4 مباشرة
        if not episodes:
            episodes = self._extractEpisodesFromPage(data)
        
        if episodes:
            for ep in episodes:
                self.addVideo({
                    'type': 'video',
                    'title': '%s - %s' % (series_title, ep['title']) if series_title else ep['title'],
                    'url': ep['url'],
                    'icon': ep.get('icon', icon),
                    'desc': desc
                })
        else:
            # عرض الترويجي إذا لم توجد حلقات
            promo = self._extractPromoVideo(data)
            if promo:
                self.addVideo({
                    'type': 'video',
                    'title': '%s - العرض الترويجي' % series_title,
                    'url': promo,
                    'icon': icon,
                    'desc': desc
                })
            
            self.addMarker({
                'title': 'لا توجد حلقات متاحة للتحميل حالياً',
                'desc': 'يمكن مشاهدة الحلقات على البث المباشر للقناة\n\n' + desc
            })

    def _extractEpisodesFromJS(self, data, content_id):
        """استخراج الحلقات من كود JavaScript في الصفحة"""
        printDBG('iFilmArabic._extractEpisodesFromJS')
        episodes = []
        
        # البحث عن عدد الحلقات: var inter_ = 31;
        inter_match = re.search(r'var\s+inter_\s*=\s*(\d+)', data)
        if not inter_match:
            printDBG('iFilmArabic: inter_ not found')
            return episodes
        
        total_episodes = int(inter_match.group(1))
        printDBG('iFilmArabic: Found %d episodes' % total_episodes)
        
        # البحث عن معرف المسلسل: var ID_Serial = 72531;
        id_match = re.search(r'var\s+ID_Serial\s*=\s*(\d+)', data)
        if id_match:
            series_id = id_match.group(1)
        elif content_id:
            series_id = content_id
        else:
            printDBG('iFilmArabic: ID_Serial not found')
            return episodes
        
        # البحث عن اللغة: var langE = "ar";
        lang_match = re.search(r'var\s+langE\s*=\s*["\'](\w*)["\']', data)
        lang = lang_match.group(1) if lang_match else 'ar'
        if lang == 'fa':
            lang = ''
        
        printDBG('iFilmArabic: Series ID: %s, Language: %s' % (series_id, lang))
        
        # بناء روابط الحلقات
        # رابط HLS: https://vod.ifilmtv.ir/hls/ar72531/,1,1_320,.mp4.urlset/master.m3u8
        # رابط MP4 بديل: https://preview.presstv.ir/ifilm/ar72531/1.mp4
        
        for i in range(1, total_episodes + 1):
            # رابط HLS (جودة عالية)
            hls_url = 'https://vod.ifilmtv.ir/hls/%s%s/,%d,%d_320,.mp4.urlset/master.m3u8' % (lang, series_id, i, i)
            
            # رابط الصورة
            img_url = 'https://preview.presstv.ir/ifilm/%s%s/%d.png' % (lang, series_id, i)
            
            episodes.append({
                'title': 'الحلقة %d' % i,
                'url': hls_url,
                'icon': img_url
            })
        
        printDBG('iFilmArabic: Built %d episode URLs' % len(episodes))
        return episodes

    def _getEpisodesFromAPI(self, content_id):
        """جلب الحلقات من API GetParts"""
        printDBG('iFilmArabic._getEpisodesFromAPI content_id: %s' % content_id)
        episodes = []
        
        # جرب روابط API مختلفة
        api_urls = [
            self.MAIN_URL + 'Series/GetParts/' + content_id,
            self.MAIN_URL + 'Series/GetParts?id=' + content_id,
            self.MAIN_URL + 'Series/GetParts?contentId=' + content_id,
            self.MAIN_URL + 'api/Series/GetParts/' + content_id,
            self.MAIN_URL + 'Series/Parts/' + content_id,
            self.MAIN_URL + 'Film/GetParts/' + content_id,
        ]
        
        # إضافة headers خاصة للـ AJAX
        ajax_params = {
            'header': {
                'User-Agent': self.USER_AGENT,
                'Accept': 'application/json, text/html, */*',
                'Accept-Language': 'ar,en;q=0.9',
                'Referer': self.MAIN_URL + 'Series/Content/' + content_id,
                'X-Requested-With': 'XMLHttpRequest'
            }
        }
        
        for api_url in api_urls:
            try:
                printDBG('iFilmArabic: Trying API URL: %s' % api_url)
                sts, data = self.getPage(api_url, ajax_params)
                if not sts or not data:
                    continue
                
                printDBG('iFilmArabic: API response length: %d' % len(data))
                printDBG('iFilmArabic: API response preview: %s' % data[:500])
                
                # محاولة تحليل JSON
                try:
                    json_data = json_loads(data)
                    if isinstance(json_data, list):
                        for i, item in enumerate(json_data):
                            if isinstance(item, dict):
                                ep_url = item.get('VideoUrl', item.get('videoUrl', item.get('url', item.get('Url', item.get('src', item.get('file', ''))))))
                                ep_title = item.get('Title', item.get('title', item.get('Name', item.get('name', 'الحلقة %d' % (i + 1)))))
                                ep_icon = item.get('ImageUrl', item.get('imageUrl', item.get('image', item.get('poster', ''))))
                            else:
                                ep_url = str(item)
                                ep_title = 'الحلقة %d' % (i + 1)
                                ep_icon = ''
                            
                            if ep_url:
                                ep_url = self._normalizeUrl(ep_url)
                                if '.mp4' in ep_url or '.m3u8' in ep_url:
                                    episodes.append({
                                        'title': ep_title,
                                        'url': ep_url,
                                        'icon': self._normalizeUrl(ep_icon) if ep_icon else ''
                                    })
                    elif isinstance(json_data, dict):
                        # قد تكون البيانات في مفتاح معين
                        items = json_data.get('parts', json_data.get('episodes', json_data.get('items', json_data.get('data', []))))
                        if isinstance(items, list):
                            for i, item in enumerate(items):
                                if isinstance(item, dict):
                                    ep_url = item.get('VideoUrl', item.get('videoUrl', item.get('url', '')))
                                    ep_title = item.get('Title', item.get('title', 'الحلقة %d' % (i + 1)))
                                    if ep_url:
                                        episodes.append({
                                            'title': ep_title,
                                            'url': self._normalizeUrl(ep_url),
                                            'icon': ''
                                        })
                except:
                    printExc()
                
                # محاولة تحليل HTML إذا لم نجد JSON
                if not episodes:
                    # البحث عن روابط الحلقات في HTML
                    # نمط: <a href="...mp4">Download</a> أو <a href="...mp4">الحلقة X</a>
                    pattern = r'<a[^>]+href=["\']([^"\']+\.mp4[^"\']*)["\'][^>]*>([^<]*)</a>'
                    matches = re.findall(pattern, data, re.IGNORECASE)
                    
                    for ep_url, ep_title in matches:
                        ep_url = self._normalizeUrl(ep_url)
                        ep_title = ep_title.strip() if ep_title.strip() else 'حلقة'
                        if ep_url and '@time' not in ep_url:
                            episodes.append({
                                'title': ep_title,
                                'url': ep_url,
                                'icon': ''
                            })
                    
                    # نمط بديل: روابط video.ifilmtv.ir
                    if not episodes:
                        mp4_pattern = r'(https?://video\.ifilmtv\.ir[^"\'<>\s]+\.mp4)'
                        mp4_matches = re.findall(mp4_pattern, data, re.IGNORECASE)
                        
                        # أيضاً البحث عن روابط /UploadedFiles/Video/
                        mp4_pattern2 = r'["\']([^"\']*?/UploadedFiles/Video/[^"\']+\.mp4)["\']'
                        mp4_matches.extend(re.findall(mp4_pattern2, data, re.IGNORECASE))
                        
                        seen = set()
                        for i, ep_url in enumerate(mp4_matches):
                            ep_url = self._normalizeUrl(ep_url)
                            if ep_url in seen or '@time' in ep_url:
                                continue
                            seen.add(ep_url)
                            
                            # استخراج رقم الحلقة من الرابط
                            num_match = re.search(r'[_-](\d{1,3})[_-]|[Ee]p?(\d+)|[Pp]art(\d+)|قسمت[_-]?(\d+)', ep_url)
                            if num_match:
                                ep_num = next((g for g in num_match.groups() if g), None)
                                ep_title = 'الحلقة %s' % ep_num
                            else:
                                ep_title = 'الحلقة %d' % (len(episodes) + 1)
                            
                            episodes.append({
                                'title': ep_title,
                                'url': ep_url,
                                'icon': ''
                            })
                
                if episodes:
                    printDBG('iFilmArabic: Found %d episodes from API' % len(episodes))
                    break
                    
            except:
                printExc()
        
        # ترتيب الحلقات حسب الرقم
        def get_num(ep):
            m = re.search(r'(\d+)', ep['title'])
            return int(m.group(1)) if m else 0
        episodes.sort(key=get_num)
        
        return episodes

    def _extractEpisodesFromHTML(self, data):
        """استخراج الحلقات من HTML الصفحة"""
        printDBG('iFilmArabic._extractEpisodesFromHTML')
        episodes = []
        
        # البحث عن قسم "شاهد الحلقات"
        episodes_section = self.cm.ph.getDataBeetwenMarkers(data, 'شاهد الحلقات', '</section>', False)[1]
        if not episodes_section:
            episodes_section = self.cm.ph.getDataBeetwenMarkers(data, 'episodes', '</div>', False)[1]
        if not episodes_section:
            episodes_section = data
        
        # البحث عن روابط الحلقات
        # نمط 1: روابط مع Download
        pattern1 = r'<a[^>]+href=["\']([^"\']+\.mp4[^"\']*)["\'][^>]*>\s*(?:Download|تحميل|الحلقة[^<]*)</a>'
        matches = re.findall(pattern1, episodes_section, re.IGNORECASE)
        
        # نمط 2: روابط video.ifilmtv.ir
        pattern2 = r'href=["\']([^"\']*video\.ifilmtv\.ir[^"\']+\.mp4[^"\']*)["\']'
        matches.extend(re.findall(pattern2, episodes_section, re.IGNORECASE))
        
        # نمط 3: روابط UploadedFiles/Video
        pattern3 = r'href=["\']([^"\']+/UploadedFiles/Video/[^"\']+\.mp4[^"\']*)["\']'
        matches.extend(re.findall(pattern3, episodes_section, re.IGNORECASE))
        
        found = set()
        for ep_url in matches:
            ep_url = self._normalizeUrl(ep_url)
            if ep_url in found or '@time' in ep_url:
                continue
            found.add(ep_url)
            
            # استخراج رقم الحلقة
            num_match = re.search(r'[_-](\d{1,3})[_-]|[Ee]p?(\d+)|[Pp]art(\d+)', ep_url)
            if num_match:
                ep_num = next((g for g in num_match.groups() if g), None)
                ep_title = 'الحلقة %s' % ep_num
            else:
                ep_title = 'الحلقة %d' % (len(episodes) + 1)
            
            episodes.append({
                'title': ep_title,
                'url': ep_url,
                'icon': ''
            })
        
        # ترتيب
        def get_num(ep):
            m = re.search(r'(\d+)', ep['title'])
            return int(m.group(1)) if m else 0
        episodes.sort(key=get_num)
        
        return episodes

    def _extractEpisodesFromPage(self, data):
        """استخراج روابط mp4 مباشرة من الصفحة"""
        printDBG('iFilmArabic._extractEpisodes')
        episodes = []
        found = set()
        
        patterns = [
            r'https?://video\.ifilmtv\.ir[^"\'<>\s\)]+\.mp4',
            r'/UploadedFiles/Video/[^"\'<>\s\)]+\.mp4',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, data, re.IGNORECASE)
            for url in matches:
                url = self._normalizeUrl(url)
                if url not in found and '@time' not in url:
                    found.add(url)
        
        for i, url in enumerate(found):
            ep_num = None
            match = re.search(r'[_-](\d{1,3})[_-]|[Ee]p?(\d+)|[Pp]art(\d+)', url)
            if match:
                ep_num = next((g for g in match.groups() if g), None)
            
            title = 'الحلقة %s' % ep_num if ep_num else 'الحلقة %d' % (i + 1)
            episodes.append({'title': title, 'url': url})
        
        def get_num(ep):
            m = re.search(r'(\d+)', ep['title'])
            return int(m.group(1)) if m else 0
        episodes.sort(key=get_num)
        
        return episodes

    def _extractPromoVideo(self, data):
        patterns = [
            r'https?://video\.ifilmtv\.ir[^"\'<>\s\)]+@time\.mp4',
            r'href=["\']([^"\']+@time\.mp4[^"\']*)["\']',
            r'href=["\']([^"\']+\.mp4[^"\']*)["\']',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, data, re.IGNORECASE)
            if match:
                url = match.group(1) if match.lastindex else match.group(0)
                return self._normalizeUrl(url)
        return None

    def _extractDescForItem(self, data, content_id, content_type):
        """استخراج الوصف لعنصر معين من صفحة القائمة"""
        desc = ''
        
        try:
            # البحث عن نص بالقرب من رابط المحتوى
            # نمط 1: <a href="...Content/ID...">...</a>...<p>الوصف</p>
            pattern1 = content_type + r'/Content/' + content_id + r'[^"\']*["\'][^>]*>.*?</a>.*?<p[^>]*>([^<]{10,300})</p>'
            match = re.search(pattern1, data, re.DOTALL | re.IGNORECASE)
            if match:
                desc = match.group(1).strip()
            
            # نمط 2: البحث عن span أو div بالقرب من الرابط
            if not desc:
                pattern2 = content_type + r'/Content/' + content_id + r'.*?<(?:span|div)[^>]*class=["\'][^"\']*desc[^"\']*["\'][^>]*>([^<]+)<'
                match = re.search(pattern2, data, re.DOTALL | re.IGNORECASE)
                if match:
                    desc = match.group(1).strip()
                
        except:
            pass
        
        # تنظيف الوصف
        if desc:
            desc = re.sub(r'<[^>]+>', '', desc)  # إزالة HTML tags
            desc = re.sub(r'\s+', ' ', desc).strip()
            if len(desc) > 200:
                desc = desc[:200] + '...'
        
        return desc

    # ==================== الأفلام ====================
    
    def listFilmsList(self, cItem):
        printDBG('iFilmArabic.listFilmsList')
        
        page = cItem.get('page', 1)
        base_url = cItem.get('url', self.MAIN_URL + 'Film')
        
        if page > 1:
            url = '%s?order=1&page=%d' % (base_url.split('?')[0], page)
        else:
            url = base_url
        
        sts, data = self.getPage(url)
        if not sts:
            return
        
        items = self._parseContentList(data, 'film')
        printDBG('iFilmArabic: Found %d films' % len(items))
        
        for item in items:
            self.addDir({
                'name': 'category',
                'category': 'film_details',
                'title': item['title'],
                'url': item['url'],
                'icon': item['icon'],
                'desc': item.get('desc', ''),
            })
        
        if len(items) >= self.ITEMS_PER_PAGE:
            self.addDir({
                'name': 'category',
                'category': 'films_list',
                'title': '⬅️ الصفحة التالية (%d)' % (page + 1),
                'url': base_url,
                'icon': self.DEFAULT_ICON_URL,
                'page': page + 1
            })

    def listFilmDetails(self, cItem):
        printDBG('iFilmArabic.listFilmDetails')
        
        url = cItem.get('url', '').rstrip('?')
        if not url:
            return
        
        # استخراج معرف المحتوى
        content_id = None
        match = re.search(r'/Content/(\d+)', url)
        if match:
            content_id = match.group(1)
        
        sts, data = self.getPage(url)
        if not sts:
            return
        
        desc = self._extractDescription(data)
        poster = self._extractPoster(data)
        icon = poster if poster else cItem.get('icon', self.DEFAULT_ICON_URL)
        
        video_url = None
        
        # الطريقة 1: استخدام API
        if content_id:
            api_url = self.MAIN_URL + 'Film/GetParts/' + content_id
            try:
                sts2, api_data = self.getPage(api_url)
                if sts2 and api_data:
                    # البحث عن رابط mp4
                    mp4_match = re.search(r'https?://video\.ifilmtv\.ir[^"\'<>\s]+\.mp4', api_data, re.IGNORECASE)
                    if mp4_match:
                        video_url = mp4_match.group(0)
                    else:
                        mp4_match = re.search(r'href=["\']([^"\']+\.mp4[^"\']*)["\']', api_data, re.IGNORECASE)
                        if mp4_match:
                            video_url = self._normalizeUrl(mp4_match.group(1))
            except:
                printExc()
        
        # الطريقة 2: استخراج من الصفحة
        if not video_url:
            video_url = self._extractFilmVideo(data)
        
        if video_url:
            self.addVideo({
                'type': 'video',
                'title': cItem.get('title', 'فيلم'),
                'url': video_url,
                'icon': icon,
                'desc': desc
            })
        else:
            # عرض الترويجي إذا لم يوجد الفيلم
            promo = self._extractPromoVideo(data)
            if promo:
                self.addVideo({
                    'type': 'video',
                    'title': '%s - العرض الترويجي' % cItem.get('title', 'فيلم'),
                    'url': promo,
                    'icon': icon,
                    'desc': desc
                })
            
            self.addMarker({
                'title': 'الفيلم غير متاح للتحميل حالياً',
                'desc': desc
            })

    def _extractFilmVideo(self, data):
        patterns = [
            r'https?://video\.ifilmtv\.ir[^"\'<>\s]+\.mp4',
            r'href=["\']([^"\']+\.mp4[^"\']*)["\']',
            r'src=["\']([^"\']+\.mp4[^"\']*)["\']',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, data, re.IGNORECASE)
            if match:
                url = match.group(1) if match.lastindex else match.group(0)
                return self._normalizeUrl(url)
        return None

    # ==================== البرامج ====================
    
    def listProgramsList(self, cItem):
        printDBG('iFilmArabic.listProgramsList')
        
        page = cItem.get('page', 1)
        base_url = cItem.get('url', self.MAIN_URL + 'Program')
        
        # صفحة البرامج تحمّل المحتوى ديناميكياً عبر AJAX
        # لذا نجلب البرامج من الصفحة الرئيسية أولاً
        
        items = []
        added = set()
        
        if page == 1:
            # جلب البرامج من الصفحة الرئيسية
            sts, data = self.getPage(self.MAIN_URL)
            if sts:
                items = self._extractProgramsFromHome(data)
                printDBG('iFilmArabic: Found %d programs from home page' % len(items))
        
        # إذا لم نجد برامج من الصفحة الرئيسية، نجرب صفحة البرامج
        if not items:
            if page > 1:
                url = '%s?order=1&page=%d' % (base_url.split('?')[0], page)
            else:
                url = base_url
            
            sts, data = self.getPage(url)
            if sts:
                items = self._parseContentList(data, 'Program')
                printDBG('iFilmArabic: Found %d programs from programs page' % len(items))
        
        # إضافة البرامج الثابتة المعروفة إذا لم نجد شيئاً
        if not items:
            items = self._getKnownPrograms()
            printDBG('iFilmArabic: Using %d known programs' % len(items))
        
        for item in items:
            if item['url'] in added:
                continue
            added.add(item['url'])
            
            self.addDir({
                'name': 'category',
                'category': 'program_episodes',
                'title': item['title'],
                'url': item['url'],
                'icon': item['icon'],
                'desc': item.get('desc', ''),
            })
        
        if len(items) >= self.ITEMS_PER_PAGE:
            self.addDir({
                'name': 'category',
                'category': 'programs_list',
                'title': '⬅️ الصفحة التالية (%d)' % (page + 1),
                'url': base_url,
                'icon': self.DEFAULT_ICON_URL,
                'page': page + 1
            })
    
    def _extractProgramsFromHome(self, data):
        """استخراج البرامج من الصفحة الرئيسية"""
        printDBG('iFilmArabic._extractProgramsFromHome')
        items = []
        added = set()
        
        # البحث عن قسم البرامج في الصفحة الرئيسية
        # النمط: <a href="/Program/Content/ID">...<h5>العنوان</h5>...</a>
        
        # نمط 1: روابط البرامج مع العناوين
        pattern1 = r'<a[^>]+href=["\']([^"\']*Program/Content/(\d+)[^"\']*)["\'][^>]*>.*?<h[1-6][^>]*>([^<]+)</h[1-6]>'
        matches = re.findall(pattern1, data, re.DOTALL | re.IGNORECASE)
        
        for url, content_id, title in matches:
            title = self._cleanTitle(title)
            if not title:
                continue
            
            url = self._normalizeUrl(url)
            if url in added:
                continue
            added.add(url)
            
            # البحث عن الصورة
            img_pattern = r'<a[^>]+href=["\'][^"\']*Program/Content/' + content_id + r'[^"\']*["\'][^>]*>\s*<img[^>]+src=["\']([^"\']+)["\']'
            img_match = re.search(img_pattern, data, re.IGNORECASE)
            icon = self._normalizeUrl(img_match.group(1)) if img_match else self.DEFAULT_ICON_URL
            icon = self._getHighQualityIcon(icon)
            
            # البحث عن الوصف
            desc_pattern = r'Program/Content/' + content_id + r'[^"\']*["\'][^>]*>.*?</a>.*?<p[^>]*>([^<]{10,300})</p>'
            desc_match = re.search(desc_pattern, data, re.DOTALL | re.IGNORECASE)
            desc = desc_match.group(1).strip() if desc_match else ''
            
            items.append({
                'title': title,
                'url': url,
                'icon': icon,
                'desc': desc
            })
        
        # نمط 2: البحث عن روابط بسيطة
        if not items:
            pattern2 = r'href=["\']([^"\']*Program/Content/(\d+)[^"\']*)["\']'
            url_matches = re.findall(pattern2, data, re.IGNORECASE)
            
            for url, content_id in url_matches:
                url = self._normalizeUrl(url)
                if url in added:
                    continue
                added.add(url)
                
                # البحث عن العنوان في السياق
                title_pattern = r'Program/Content/' + content_id + r'[^"\']*["\'][^>]*>.*?(?:<h[1-6][^>]*>([^<]+)</h|#####\s*([^\n]+))'
                title_match = re.search(title_pattern, data, re.DOTALL | re.IGNORECASE)
                if title_match:
                    title = self._cleanTitle(title_match.group(1) or title_match.group(2))
                else:
                    title = 'برنامج ' + content_id
                
                if not title:
                    continue
                
                items.append({
                    'title': title,
                    'url': url,
                    'icon': self.DEFAULT_ICON_URL,
                    'desc': ''
                })
        
        return items
    
    def _getKnownPrograms(self):
        """قائمة البرامج المعروفة الثابتة"""
        printDBG('iFilmArabic._getKnownPrograms')
        
        # هذه البرامج مستخرجة من الصفحة الرئيسية
        known_programs = [
            {
                'title': 'أنتم وآي فيلم',
                'url': self.MAIN_URL + 'Program/Content/69698',
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'برنامج يومي يطلعكم على آخر أخبار جدول عرض قناة آي فيلم وجسر تواصل بين القناة وجمهورها'
            },
            {
                'title': 'خلف الكاميرا',
                'url': self.MAIN_URL + 'Program/Content/15159',
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'يتطرق برنامج "خلف الكاميرا" الى تفاصيل المسلسلات والافلام خلال الانتاج ويقوم بعرض مشاهد من كواليسها'
            },
            {
                'title': 'خارج الإطار',
                'url': self.MAIN_URL + 'Program/Content/16639',
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'برنامج أسبوعي يستضيف فنانين إيرانيين من ممثلين، مغنين، ممثلين بدلاء ليحدثونا عن حياتهم الشخصية والفنية'
            },
            {
                'title': 'عدسة آي فيلم',
                'url': self.MAIN_URL + 'Program/Content/16529',
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'برنامج يحتوي على تقارير خاصة من أروقة وصالات عرض أهم الفعاليات الفنية بما فيها المهرجانات في ايران'
            },
            {
                'title': 'سهرة مع فنان',
                'url': self.MAIN_URL + 'Program/Content/25477',
                'icon': self.DEFAULT_ICON_URL,
                'desc': 'برنامج يستضيف الفنانين الإيرانيين للتحدث عن مسيرتهم الفنية'
            },
        ]
        
        return known_programs

    def listProgramEpisodes(self, cItem):
        """عرض حلقات البرنامج عبر API"""
        printDBG('iFilmArabic.listProgramEpisodes url: %s' % cItem.get('url', ''))
        
        url = cItem.get('url', '').rstrip('?')
        if not url:
            return
        
        # استخراج معرف المحتوى من الرابط
        content_id = None
        match = re.search(r'/Content/(\d+)', url)
        if match:
            content_id = match.group(1)
        
        if not content_id:
            printDBG('iFilmArabic: No content ID found')
            return
        
        # جلب صفحة البرنامج للحصول على الوصف والصورة
        sts, data = self.getPage(url)
        if not sts:
            return
        
        program_title = cItem.get('title', '')
        desc = self._extractDescription(data)
        poster = self._extractPoster(data)
        icon = poster if poster else cItem.get('icon', self.DEFAULT_ICON_URL)
        
        # جلب الحلقات عبر API
        episodes = self._getProgramEpisodes(content_id)
        
        if episodes:
            for ep in episodes:
                self.addVideo({
                    'type': 'video',
                    'title': '%s - %s' % (program_title, ep['title']) if program_title else ep['title'],
                    'url': ep['url'],
                    'icon': ep.get('icon', icon),
                    'desc': desc
                })
        else:
            # إذا لم توجد حلقات
            promo = self._extractPromoVideo(data)
            if promo:
                self.addVideo({
                    'type': 'video',
                    'title': '%s - العرض الترويجي' % program_title,
                    'url': promo,
                    'icon': icon,
                    'desc': desc
                })
            
            self.addMarker({
                'title': 'لا توجد حلقات متاحة حالياً',
                'desc': desc
            })

    def _getProgramEpisodes(self, content_id):
        """جلب حلقات البرنامج من API"""
        printDBG('iFilmArabic._getProgramEpisodes content_id: %s' % content_id)
        episodes = []
        
        # API URL: /Home/PageingAttachmentItem?id=ID&page=PAGE&size=SIZE
        api_url = self.MAIN_URL + 'Home/PageingAttachmentItem'
        
        page = 1
        max_pages = 20  # حد أقصى للصفحات
        
        while page <= max_pages:
            try:
                params = {
                    'id': content_id,
                    'page': str(page),
                    'size': '20'
                }
                
                # إنشاء URL مع المعاملات
                full_url = api_url + '?' + '&'.join(['%s=%s' % (k, v) for k, v in params.items()])
                
                sts, data = self.getPage(full_url)
                if not sts or not data:
                    break
                
                # محاولة تحليل JSON
                try:
                    import json
                    items = json.loads(data)
                    
                    if not items or len(items) == 0:
                        break
                    
                    for item in items:
                        video_url = item.get('VideoAddress', '')
                        if video_url:
                            # تحويل الرابط إلى رابط كامل
                            if video_url.startswith('/'):
                                video_url = 'https://fa.ifilmtv.ir' + video_url
                            elif not video_url.startswith('http'):
                                video_url = 'https://fa.ifilmtv.ir/' + video_url
                            
                            episode_num = item.get('Episode', '')
                            ep_title = 'الحلقة %s' % episode_num if episode_num else 'حلقة'
                            
                            img_url = item.get('ImageAddress_M', '')
                            if img_url and not img_url.startswith('http'):
                                img_url = self.MAIN_URL.rstrip('/') + img_url
                            
                            episodes.append({
                                'title': ep_title,
                                'url': video_url,
                                'icon': img_url
                            })
                    
                    # إذا كان عدد العناصر أقل من الحجم المطلوب، لا توجد صفحات أخرى
                    if len(items) < 20:
                        break
                    
                    page += 1
                    
                except:
                    printExc()
                    break
                    
            except:
                printExc()
                break
        
        # ترتيب الحلقات حسب الرقم
        def get_num(ep):
            m = re.search(r'(\d+)', ep['title'])
            return int(m.group(1)) if m else 0
        episodes.sort(key=get_num)
        
        printDBG('iFilmArabic: Found %d program episodes' % len(episodes))
        return episodes

    # ==================== دالة التحليل الرئيسية ====================
    
    def _parseContentList(self, data, content_type):
        """تحليل قائمة المحتوى - مسلسلات أو أفلام"""
        printDBG('iFilmArabic._parseContentList type: %s' % content_type)
        items = []
        added = set()
        
        # استخراج كتل المحتوى (كل عنصر في القائمة)
        # البحث عن البنية: <div class="..."><a href="..."><img><h6>title</h6></a><p>desc</p></div>
        
        # النمط المحسّن: استخراج كتل كاملة أولاً
        block_pattern = r'<div[^>]*class=["\'][^"\']*(?:item|content|card|panel)[^"\']*["\'][^>]*>(.*?)</div>\s*</div>'
        blocks = re.findall(block_pattern, data, re.DOTALL | re.IGNORECASE)
        
        if not blocks:
            # نمط بديل للكتل
            block_pattern2 = r'<a[^>]+href=["\'][^"\']*' + content_type + r'/Content/\d+[^"\']*["\'][^>]*>.*?</a>'
            blocks = re.findall(block_pattern2, data, re.DOTALL | re.IGNORECASE)
        
        # النمط الأول: HTML كامل مع a > img > h6/h3
        # <a href="/series/Content/ID"><img src="..."><h6>العنوان</h6></a>
        pattern1 = r'<a[^>]+href=["\']([^"\']*' + content_type + r'/Content/(\d+)[^"\']*)["\'][^>]*>.*?<img[^>]+src=["\']([^"\']+)["\'].*?<h[1-6][^>]*>([^<]+)</h[1-6]>'
        matches = re.findall(pattern1, data, re.DOTALL | re.IGNORECASE)
        
        printDBG('iFilmArabic: Pattern1 found %d matches' % len(matches))
        
        for url, content_id, icon, title in matches:
            title = self._cleanTitle(title)
            if not title:
                continue
            
            url = self._normalizeUrl(url)
            if url in added:
                continue
            added.add(url)
            
            icon = self._normalizeUrl(icon)
            icon = self._getHighQualityIcon(icon)
            
            # البحث عن الوصف القريب من هذا المحتوى
            desc = self._extractDescForItem(data, content_id, content_type)
            
            items.append({
                'title': title,
                'url': url,
                'icon': icon if icon else self.DEFAULT_ICON_URL,
                'desc': desc
            })
        
        # النمط الثاني: إذا لم نجد بالأول
        if not items:
            # استخراج جميع روابط المحتوى
            url_pattern = r'href=["\']([^"\']*' + content_type + r'/Content/(\d+)[^"\']*)["\']'
            url_matches = re.findall(url_pattern, data, re.IGNORECASE)
            
            printDBG('iFilmArabic: Pattern2 found %d URL matches' % len(url_matches))
            
            for url, content_id in url_matches:
                url = self._normalizeUrl(url)
                if url in added:
                    continue
                added.add(url)
                
                # البحث عن العنوان القريب من هذا الرابط
                title_pattern = r'href=["\'][^"\']*' + content_type + r'/Content/' + content_id + r'[^"\']*["\'][^>]*>.*?<h[1-6][^>]*>([^<]+)</h[1-6]>'
                title_match = re.search(title_pattern, data, re.DOTALL | re.IGNORECASE)
                
                if title_match:
                    title = self._cleanTitle(title_match.group(1))
                else:
                    # بحث بديل عن العنوان
                    alt_title_pattern = r'<h[1-6][^>]*>([^<]+)</h[1-6]>\s*</a>\s*.*?href=["\'][^"\']*Content/' + content_id
                    alt_match = re.search(alt_title_pattern, data, re.DOTALL | re.IGNORECASE)
                    title = self._cleanTitle(alt_match.group(1)) if alt_match else ''
                
                if not title:
                    continue
                
                # البحث عن الصورة
                img_pattern = r'<a[^>]+href=["\'][^"\']*Content/' + content_id + r'[^"\']*["\'][^>]*>\s*<img[^>]+src=["\']([^"\']+)["\']'
                img_match = re.search(img_pattern, data, re.IGNORECASE)
                icon = self._normalizeUrl(img_match.group(1)) if img_match else self.DEFAULT_ICON_URL
                icon = self._getHighQualityIcon(icon)
                
                # البحث عن الوصف
                desc = self._extractDescForItem(data, content_id, content_type)
                
                items.append({
                    'title': title,
                    'url': url,
                    'icon': icon,
                    'desc': desc
                })
        
        # النمط الثالث: بحث أبسط
        if not items:
            # البحث عن أي رابط يحتوي على Content/ID
            simple_pattern = r'<a[^>]+href=["\']([^"\']*' + content_type + r'/Content/(\d+)[^"\']*)["\']'
            simple_matches = re.findall(simple_pattern, data, re.IGNORECASE)
            
            printDBG('iFilmArabic: Pattern3 found %d simple matches' % len(simple_matches))
            
            for url, content_id in simple_matches:
                url = self._normalizeUrl(url)
                if url in added:
                    continue
                added.add(url)
                
                # محاولة إيجاد أي عنوان قريب
                context_start = data.find(content_id)
                if context_start > 0:
                    context = data[max(0, context_start-500):context_start+500]
                    h_match = re.search(r'<h[1-6][^>]*>([^<]{2,50})</h[1-6]>', context)
                    title = self._cleanTitle(h_match.group(1)) if h_match else 'محتوى ' + content_id
                else:
                    title = 'محتوى ' + content_id
                
                items.append({
                    'title': title,
                    'url': url,
                    'icon': self.DEFAULT_ICON_URL,
                    'desc': ''
                })
        
        printDBG('iFilmArabic: Total items found: %d' % len(items))
        return items

    # ==================== دوال مساعدة ====================
    
    def _extractDescription(self, data):
        desc = ''
        patterns = [
            r'<p[^>]*>([^<]{50,500})</p>',
            r'<div[^>]*class=["\'][^"\']*desc[^"\']*["\'][^>]*>([\s\S]{30,500}?)</div>',
            r'<strong>([^<]{50,500})</strong>',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, data, re.IGNORECASE)
            if match:
                desc = match.group(1)
                desc = re.sub(r'<[^>]+>', '', desc)
                desc = re.sub(r'\s+', ' ', desc).strip()
                if len(desc) > 30:
                    break
        return desc

    def _extractPoster(self, data):
        patterns = [
            r'<img[^>]+src=["\']([^"\']+MeduimSize[^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']+LargeSize[^"\']+)["\']',
            r'og:image["\'][^>]+content=["\']([^"\']+)["\']',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, data, re.IGNORECASE)
            if match:
                return self._normalizeUrl(match.group(1))
        return ''

    def _getHighQualityIcon(self, icon):
        if icon and 'SmallSize' in icon:
            return icon.replace('SmallSize', 'MeduimSize')
        return icon

    def _normalizeUrl(self, url):
        if not url:
            return ''
        url = url.strip()
        
        if url.startswith('//'):
            url = 'https:' + url
        elif url.startswith('/'):
            url = self.MAIN_URL.rstrip('/') + url
        elif not url.startswith('http'):
            url = self.MAIN_URL.rstrip('/') + '/' + url
        
        try:
            parsed = urllib.parse.urlparse(url)
            encoded_path = urllib.parse.quote(parsed.path, safe='/:@')
            url = urllib.parse.urlunparse((
                parsed.scheme, parsed.netloc, encoded_path,
                parsed.params, parsed.query, parsed.fragment
            ))
        except:
            pass
        
        return url

    def _cleanTitle(self, title):
        if not title:
            return ''
        title = re.sub(r'<[^>]+>', '', title)
        title = re.sub(r'\s+', ' ', title).strip()
        title = title.replace('()', '').strip()
        
        skip = ['© جميع', 'الحقوق', 'الاشتراك', 'img', 'final-logo']
        for s in skip:
            if s in title:
                return ''
        return title

    # ==================== البحث ====================
    
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("iFilmArabic.listSearchResult: %s" % searchPattern)
        searchPattern = searchPattern.lower()
        
        # البحث في المسلسلات
        for page in range(1, 4):
            url = self.MAIN_URL + 'Series' if page == 1 else self.MAIN_URL + 'Series?order=1&page=%d' % page
            sts, data = self.getPage(url)
            if sts:
                for item in self._parseContentList(data, 'series'):
                    if searchPattern in item['title'].lower():
                        self.addDir({
                            'name': 'category',
                            'category': 'series_episodes',
                            'title': '🎬 ' + item['title'],
                            'url': item['url'],
                            'icon': item['icon'],
                            'desc': 'مسلسل'
                        })
        
        # البحث في الأفلام
        for page in range(1, 4):
            url = self.MAIN_URL + 'Film' if page == 1 else self.MAIN_URL + 'Film?order=1&page=%d' % page
            sts, data = self.getPage(url)
            if sts:
                for item in self._parseContentList(data, 'film'):
                    if searchPattern in item['title'].lower():
                        self.addDir({
                            'name': 'category',
                            'category': 'film_details',
                            'title': '🎥 ' + item['title'],
                            'url': item['url'],
                            'icon': item['icon'],
                            'desc': 'فيلم'
                        })
        
        # البحث في البرامج
        for page in range(1, 4):
            url = self.MAIN_URL + 'Program' if page == 1 else self.MAIN_URL + 'Program?order=1&page=%d' % page
            sts, data = self.getPage(url)
            if sts:
                for item in self._parseContentList(data, 'program'):
                    if searchPattern in item['title'].lower():
                        self.addDir({
                            'name': 'category',
                            'category': 'program_episodes',
                            'title': '📺 ' + item['title'],
                            'url': item['url'],
                            'icon': item['icon'],
                            'desc': 'برنامج'
                        })

    # ==================== تشغيل الفيديو ====================
    
    def getLinksForVideo(self, cItem):
        printDBG("iFilmArabic.getLinksForVideo")
        url = cItem.get('url', '')
        if not url:
            return []
        
        url = self._normalizeUrl(url)
        links = []
        
        params = {
            'User-Agent': self.USER_AGENT,
            'Referer': self.MAIN_URL,
            'Accept': '*/*',
            'Origin': 'https://ar.ifilmtv.ir'
        }
        
        # إذا كان رابط HLS
        if '.m3u8' in url:
            # الرابط الأصلي HLS
            links.append({
                'name': 'HLS (جودة عالية)',
                'url': strwithmeta(url, params),
                'need_resolve': 1
            })
            
            # محاولة استخراج رابط MP4 بديل
            # من: https://vod.ifilmtv.ir/hls/ar72531/,1,1_320,.mp4.urlset/master.m3u8
            # إلى: https://preview.presstv.ir/ifilm/ar72531/1.mp4
            match = re.search(r'hls/(\w+\d+)/,(\d+),', url)
            if match:
                series_id = match.group(1)
                ep_num = match.group(2)
                mp4_url = 'https://preview.presstv.ir/ifilm/%s/%s.mp4' % (series_id, ep_num)
                links.append({
                    'name': 'MP4 (بديل)',
                    'url': strwithmeta(mp4_url, params),
                    'need_resolve': 0
                })
        else:
            # رابط MP4 مباشر
            links.append({
                'name': 'MP4',
                'url': strwithmeta(url, params),
                'need_resolve': 0
            })
        
        return links

    def getVideoLinks(self, videoUrl):
        printDBG("iFilmArabic.getVideoLinks: %s" % videoUrl)
        
        # استخراج الهيدرز من الميتا
        headers = {}
        if isinstance(videoUrl, strwithmeta):
            headers = {
                'User-Agent': videoUrl.meta.get('User-Agent', self.USER_AGENT),
                'Referer': videoUrl.meta.get('Referer', self.MAIN_URL),
            }
        
        if '.m3u8' in videoUrl:
            try:
                return getDirectM3U8Playlist(videoUrl, checkContent=True, sortWithMaxBitrate=99999999)
            except:
                printExc()
                # إذا فشل، جرب بدون فحص المحتوى
                try:
                    return getDirectM3U8Playlist(videoUrl, checkContent=False)
                except:
                    printExc()
                    return [{'name': 'HLS', 'url': videoUrl}]
        elif '.mp4' in videoUrl:
            return [{'name': 'mp4', 'url': videoUrl}]
        return []

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('iFilmArabic.handleService')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        
        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        
        printDBG("handleService: name=%s, category=%s" % (name, category))
        self.currList = []
        
        if name == None:
            self.listMainMenu({'name': 'category'})
        elif category == 'live_streams':
            self.listLiveStreams(self.currItem)
        elif category == 'series_list':
            self.listSeriesList(self.currItem)
        elif category == 'series_episodes':
            self.listSeriesEpisodes(self.currItem)
        elif category == 'films_list':
            self.listFilmsList(self.currItem)
        elif category == 'film_details':
            self.listFilmDetails(self.currItem)
        elif category == 'programs_list':
            self.listProgramsList(self.currItem)
        elif category == 'program_episodes':
            self.listProgramEpisodes(self.currItem)
        elif category == 'search':
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == 'search_history':
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            self.listMainMenu(self.currItem)

    def getFavouriteData(self, cItem):
        return str({'url': cItem['url']})
        
    def getLinksForFavourite(self, fav_data):
        try:
            params = eval(fav_data)
        except:
            params = {}
        return self.getLinksForVideo(params)


class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, iFilmArabic(), True, [])
