# -*- coding: utf-8 -*-
# Last modified: 17/10/2025 - popking (odem2014)
# typical import for a standard host
###################################################
# LOCAL import
###################################################
# localization library
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
# host main class
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
# tools - write on log, write exception infos and merge dicts
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, E2ColoR
# add metadata to url
# library for json (instead of standard json.loads and json.dumps)
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads
# read informations in m3u8
###################################################
from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import urljoin
###################################################
# FOREIGN import
###################################################
import re
import time
import base64
import os
import hashlib
from urllib.parse import quote
from urllib.parse import urlparse
###################################################
def GetConfigList():
    return []
def gettytul():
    return 'https://wecima.click/'  # main url of host
class WeCima(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'wecima', 'cookie': 'wecima.cookie'})
        self.MAIN_URL = gettytul()
        self.SEARCH_URL = self.MAIN_URL + 'search/'
        self.DEFAULT_ICON_URL = "https://raw.githubusercontent.com/oe-mirrors/e2iplayer/gh-pages/Thumbnails/wecima.png"
        self.HEADER = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,ar;q=0.8',
            'Referer': self.MAIN_URL,
            'Connection': 'keep-alive'
        }
        self.defaultParams = {
            'header': self.HEADER,
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': False,
            'cookiefile': self.COOKIE_FILE
        }
    def getFullUrl(self, url):
        if not url:
            return ''
        if url.startswith('//'):
            url = 'https:' + url
        url = url.replace('%25', '%') 
        return urljoin(self.MAIN_URL, url)
    def getPage(self, baseUrl, addParams=None, post_data=None):
        if addParams is None:
            addParams = dict(self.defaultParams)
        sts, data = self.cm.getPage(baseUrl, addParams, post_data)
        return sts, data
    ###################################################
    # MAIN MENU
    ###################################################
    def listMainMenu(self, cItem):
        printDBG('WeCima.listMainMenu')
        MAIN_CAT_TAB = [
            {'category': 'movies_categories', 'title': 'الافلام'},
            {'category': 'series_categories', 'title': 'المسلسلات'},
            {'category': 'anime_categories', 'title': 'الكارتون'},
            {'category': 'other_categories', 'title': _('Others')},
        ] + self.searchItems()
        self.listsTab(MAIN_CAT_TAB, cItem)
        # Define subcategories for each folder
        self.MOVIES_CAT_TAB = [
            {'category': 'list_movies', 'title': 'افلام اجنبية', 'url': self.getFullUrl('/category/foreign-movies')},
            {'category': 'list_movies', 'title': 'افلام عربية', 'url': self.getFullUrl('/category/arabic-movies')},
            {'category': 'list_movies', 'title': 'افلام هندية', 'url': self.getFullUrl('/category/indian-movies')},
            {'category': 'list_movies', 'title': 'افلام تركية', 'url': self.getFullUrl('/category/turkish-movies')},
            {'category': 'list_movies', 'title': 'افلام اسيوية', 'url': self.getFullUrl('/category/asian-movies')},
            {'category': 'list_movies', 'title': 'افلام مدبلجة', 'url': self.getFullUrl('/category/dubbed-movies')},
        ]
        self.SERIES_CAT_TAB = [
            {'category': 'list_series', 'title': 'مسلسلات اجنبية', 'url': self.getFullUrl('/category/foreign-series')},
            {'category': 'list_series', 'title': 'مسلسلات عربية', 'url': self.getFullUrl('/category/arabic-series')},
            {'category': 'list_series', 'title': 'مسلسلات هندية', 'url': self.getFullUrl('/category/indian-series')},
            {'category': 'list_series', 'title': 'مسلسلات اسيوية', 'url': self.getFullUrl('/category/asian-series')},
            {'category': 'list_series', 'title': 'مسلسلات تركية', 'url': self.getFullUrl('/category/turkish-series')},
            {'category': 'list_series', 'title': 'مسلسلات رمضان 2026', 'url': self.getFullUrl('/category/ramadan-series-2026')},
            {'category': 'list_series', 'title': 'مسلسلات رمضان 2025', 'url': self.getFullUrl('/category/ramadan-series-2025')},
            {'category': 'list_series', 'title': 'مسلسلات رمضان 2024', 'url': self.getFullUrl('/category/ramadan-series-2024')},
            {'category': 'list_series', 'title': 'مسلسلات رمضان 2023', 'url': self.getFullUrl('/category/ramadan-series-2023')},
            {'category': 'list_series', 'title': 'مسلسلات رمضان 2022', 'url': self.getFullUrl('/category/ramadan-series-2022')},
            {'category': 'list_series', 'title': 'مسلسلات رمضان 2022', 'url': self.getFullUrl('/category/ramadan-series-2022')},
        ]
        self.ANIME_CAT_TAB = [
            {'category': 'list_anime', 'title': 'افلام انمي', 'url': self.getFullUrl('/category/anime-movies')},
            {'category': 'list_anime', 'title': 'مسلسلات انمي', 'url': self.getFullUrl('/category/anime-series')},
        ]
        self.OTHER_CAT_TAB = [
            {'category': 'list_other', 'title': _('Trend'), 'url': self.getFullUrl('/trends')},
            {'category': 'list_other', 'title': 'مصارعة', 'url': self.getFullUrl('/category/wwe-shows')},
            {'category': 'list_other', 'title': 'برامج تليفزيونية', 'url': self.getFullUrl('/category/tv-shows')},
        ]
    def listMoviesCategories(self, cItem):
        printDBG('WeCima.listMoviesCategories')
        self.listsTab(self.MOVIES_CAT_TAB, cItem)
    def listSeriesCategories(self, cItem):
        printDBG('WeCima.listSeriesCategories')
        self.listsTab(self.SERIES_CAT_TAB, cItem)
    def listAnimeCategories(self, cItem):
        printDBG('WeCima.listAnimeCategories')
        self.listsTab(self.ANIME_CAT_TAB, cItem)
    def listOtherCategories(self, cItem):
        printDBG('WeCima.listOtherCategories')
        self.listsTab(self.OTHER_CAT_TAB, cItem)
    # ###################################################
    # # LIST UNITS FROM CATEGORY PAGE (WITH PAGINATION)
    # ###################################################
    def listUnits(self, cItem):
        printDBG('WeCima.listUnits >>> %s' % cItem)
        sts, data = self.getPage(cItem['url'])
        if not sts or not data:
            return
        cache_dir = '/media/hdd/IPTVCache/'
        session_timestamp = str(int(time.time() * 1000000))
        temp_icon_dir = os.path.join(cache_dir, '.iptvplayer_icons_' + session_timestamp)
        try:
            if not os.path.exists(temp_icon_dir):
                os.makedirs(temp_icon_dir, exist_ok=True)
                printDBG("Created session-specific icon dir: " + temp_icon_dir)
        except Exception:
            printExc()
            temp_icon_dir = cache_dir
        now = time.time()
        for f in os.listdir(cache_dir):
            f_path = os.path.join(cache_dir, f)
            if os.path.isfile(f_path) and now - os.path.getmtime(f_path) > 86400:
                try:
                    os.remove(f_path)
                except Exception:
                    pass
        grid_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="Grid--WecimaPosts">', '<div class="pagination">', False)[1]
        if not grid_block:
            grid_block = data
        items = self.cm.ph.getAllItemsBeetwenMarkers(grid_block, '<div class="GridItem"', '</a>')
        for item in items:
            url = self.cm.ph.getSearchGroups(item, r'href="([^"]+)"')[0]
            if not url:
                continue
            icon = self.cm.ph.getSearchGroups(item, r'data-src="([^"]+)"')[0] or self.cm.ph.getSearchGroups(item, r'src="([^"]+)"')[0]
            if icon:
                icon_url = self.getFullUrl(icon)
                filename = hashlib.md5(icon_url.encode('utf-8')).hexdigest() + ".jpg"
                full_path = os.path.join(temp_icon_dir, filename)
                if not os.path.exists(full_path):
                    download_params = {
                        'header': self.HEADER,
                        'save_to_file': full_path,
                        'use_cookie': True,
                        'load_cookie': True,
                        'cookiefile': self.COOKIE_FILE
                    }
                    self.cm.getPage(icon_url, download_params)
                icon = "file://" + full_path if os.path.exists(full_path) else icon_url
            quality = self.cm.ph.getDataBeetwenMarkers(item, '<em class="ribbon">', '</em>', False)[1]
            quality = self.cleanHtmlStr(quality).strip()
            q_color = 'white'
            if re.search(r'4K|1080|BluRay', quality, re.I):
                q_color = 'green'
            elif re.search(r'720|HDRip|WEB', quality, re.I):
                q_color = 'yellow'
            elif re.search(r'CAM|TS|HDCAM', quality, re.I):
                q_color = 'red'
            colored_quality = "{0}[{1}]{2}".format(E2ColoR(q_color), quality if quality else 'SD', E2ColoR('white'))
            desc = self.cm.ph.getSearchGroups(item, r'<meta itemprop="description" content="([^"]+)"')[0]
            desc = self.cleanHtmlStr(desc).replace("مشاهدة وتحميل فيلم", "").strip()
            if not desc:
                desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item, '<ul class="PostItemStats">', '</ul>', False)[1]).strip()
            title_part = self.cm.ph.getDataBeetwenMarkers(item, '<strong class="tit">', '</strong>', False)[1]
            if not title_part:
                title_part = self.cm.ph.getSearchGroups(item, r'title="([^"]+)"')[0]
            title = self.cleanHtmlStr(title_part).strip()
            title = re.sub(r'مشاهدة|فيلم|مسلسل|اون لاين|مترجم(ة)?|مدبلج(ة)?|WEB-DL|BluRay', '', title).strip()
            match = re.search(r'(.+?)\s*\(?((?:20|19)\d{2})\)?$', title)
            if match:
                movie_name, movie_year = match.group(1).strip(), match.group(2).strip()
                colored_title = "{0}{1} {2}{3}{4}".format(E2ColoR('yellow'), movie_name, E2ColoR('cyan'), movie_year, E2ColoR('white'))
            else:
                colored_title = "{0}{1}{2}".format(E2ColoR('yellow'), title, E2ColoR('white'))
            params = dict(cItem)
            params.update({
                'title': colored_title,
                'url': self.getFullUrl(url),
                'icon': icon,
                'desc': "{0} | {1}".format(colored_quality, desc),
                'category': 'explore_items'
            })
            self.addDir(params)
        pagination_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="pagination">', '</div>', False)[1]
        if pagination_block:
            next_url = self.cm.ph.getSearchGroups(pagination_block, r'href="([^"]+)"[^>]*>»')[0]
            if not next_url:
                next_url = self.cm.ph.getSearchGroups(pagination_block, r'href="([^"]+)"[^>]*>[^<]*(?:التالي|Next|next)')[0]
            if not next_url:
                next_url = self.cm.ph.getSearchGroups(pagination_block, r'class="page-numbers current">.*?</a></li><li><a href="([^"]+)"')[0]
            if next_url:
                params = dict(cItem)
                params.update({
                    'title': _('Next Page »»»'),
                    'url': self.getFullUrl(next_url),
                    'category': 'list_movies'
                })
                self.addDir(params)
    ###################################################
    # EXPLORE ITEM (get list of seasons or episodes)
    ###################################################
    def exploreItems(self, cItem):
        printDBG('WeCima.exploreItems >>> %s' % cItem)
        url = cItem['url']
        sts, data = self.getPage(url)
        if not sts:
            return
        if '/series/' in url:
            seasons_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="List--Seasons--Episodes">', '</div>', False)[1]
            seasons = re.findall(r'data-id="(\d+)"\s+data-season="([^"]+)">([^<]+)</a>', seasons_block)
            if seasons:
                seasons.sort(key=lambda x: int(re.sub(r'\D', '', x[1]) if re.sub(r'\D', '', x[1]) else 0))
                for post_id, season_id, season_title in seasons:
                    params = dict(cItem)
                    params.update({
                        'title': self.cleanHtmlStr(season_title),
                        'post_id': post_id,
                        'season': season_id,
                        'category': 'list_episodes'
                    })
                    self.addDir(params)
                return
            else:
                printDBG('WeCima.exploreItems: No seasons found, searching for direct episodes block...')
                episodes_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="Seasons--Episodes">', '</singlesection>', False)[1]
                if episodes_block == "":
                    episodes_block = self.cm.ph.getDataBeetwenMarkers(data, '<div class="EpisodesList', '</div>', False)[1]
                if episodes_block != "":
                    self.extractEpisodes(episodes_block, cItem)
                else:
                    self.extractEpisodes(data, cItem)
                return
        if '/watch/' in url or '/movie/' in url:
            self.extractServers(data, cItem)
    def listEpisodes(self, cItem):
        printDBG('WeCima.listEpisodes >>> %s' % cItem)
        post_id = cItem.get('post_id')
        season = cItem.get('season')
        ajax_url = self.getFullUrl('/ajax/Episode')
        post_data = {'season': season, 'post_id': post_id}
        addParams = dict(self.defaultParams)
        addParams['header'] = MergeDicts(self.HEADER, {'X-Requested-With': 'XMLHttpRequest', 'Referer': cItem['url']})
        sts, data = self.getPage(ajax_url, addParams, post_data)
        if sts:
            self.extractEpisodes(data, cItem)
    def extractEpisodes(self, data, cItem):
        printDBG('WeCima.extractEpisodes')
        episodes = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>.*?<episodetitle>([^<]+)</episodetitle>', data, re.S)
        main_title = cItem.get('main_title', cItem.get('title', ''))
        if episodes:
            episodes.sort(key=lambda x: int(re.sub(r'\D', '', x[1]) if re.sub(r'\D', '', x[1]) else 0))
            for ep_url, ep_title in episodes:
                params = dict(cItem)
                params.update({
                    'main_title': main_title,
                    'title': self.cleanHtmlStr(ep_title),
                    'url': self.getFullUrl(ep_url),
                    'category': 'explore_items'
                })
                self.addDir(params)
    def extractServers(self, data, cItem):
        printDBG('WeCima.extractServers')
        main_title = self.cleanHtmlStr(cItem.get('main_title', ''))
        current_title = self.cleanHtmlStr(cItem.get('title', ''))
        if main_title and main_title != current_title:
            full_display_name = "%s - %s" % (main_title, current_title)
        else:
            full_display_name = current_title
        items = re.findall(r'data-url="([^"]+)"[^>]*>.*?<strong>([^<]+)</strong>', data, re.S)
        for idx, (encoded_url, server_name) in enumerate(items, 1):
            try:
                clean_url = encoded_url.replace('+', '')
                full_encoded = "aHR0c" + clean_url
                rem = len(full_encoded) % 4
                if rem: 
                    full_encoded += '=' * (4 - rem)
                decoded_url = base64.b64decode(full_encoded).decode('utf-8', errors='ignore')
                if 'http' in decoded_url:
                    try:
                        domain = urlparse(decoded_url).netloc
                    except Exception:
                        domain = 'Direct'
                    display_title = r"\c00FFFF00▶ \c00FFFFFF%s : \c0000FFFF%s \c00FFFFFF- %s" % (
                        server_name,
                        domain,
                        full_display_name
                    )
                    params = dict(cItem)
                    params.update({
                        'title': display_title,
                        'url': decoded_url,
                        'type': 'video',
                    })
                    self.addVideo(params)
            except Exception as e:
                printDBG('Error formatting server: %s' % e)
    ###################################################
    # GET LINKS FOR VIDEO
    ###################################################
    def getLinksForVideo(self, cItem):
        printDBG('WeCima.getLinksForVideo [%s]' % cItem)
        url = cItem.get('url', '')
        if not url:
            return []
        return [{'name': 'WeCima - %s' % cItem.get('title', ''), 'url': url, 'need_resolve': 1}]
    def getVideoLinks(self, url):
        printDBG("WeCima.getVideoLinks [%s]" % url)
        urlTab = []
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return urlTab
    ###################################################
    # SEARCH
    ###################################################
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("WeCima.listSearchResult searchPattern[%s]" % searchPattern)
        search_url = self.MAIN_URL + 'search'
        post_data = {'q': searchPattern.strip()}
        ajax_headers = MergeDicts(self.HEADER, {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Referer': self.MAIN_URL,
            'Connection': 'keep-alive'
        })
        addParams = dict(self.defaultParams)
        addParams.update({
            'header': ajax_headers,
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': False,
            'cookiefile': '/hdd/IPTVCache/cookies/wecima.cookie',
            'return_data': True
        })
        sts, data = self.getPage(search_url, addParams, post_data)
        if not sts:
            return
        try:
            response = json_loads(data)
            if not response.get('status', False):
                return
            results = response.get('results', [])
            for item in results:
                slug = item.get('slug', '')
                if not slug:
                    continue
                istv = item.get('istv', 0)
                prefix = 'series/' if istv == 1 else 'watch/'
                encoded_slug = quote(slug.lstrip('/'))
                url = self.getFullUrl(prefix + encoded_slug)
                title = self.cleanHtmlStr(item.get('title', ''))
                icon = item.get('image', '').replace('\\/', '/').strip()
                if icon.startswith('/'):
                    icon = self.getFullUrl(icon)
                if icon:
                    filename = hashlib.md5(icon.encode('utf-8')).hexdigest() + ".jpg"
                    full_path = os.path.join('/media/hdd/IPTVCache/', filename)
                    if not os.path.exists(full_path):
                        download_params = {
                            'header': self.HEADER,
                            'save_to_file': full_path,
                            'use_cookie': True,
                            'load_cookie': True,
                            'save_cookie': False,
                            'cookiefile': '/hdd/IPTVCache/cookies/wecima.cookie'
                        }
                        self.cm.getPage(icon, download_params)
                    if os.path.exists(full_path):
                        icon = "file://" + full_path
                else:
                    icon = self.DEFAULT_ICON_URL
                printDBG("SEARCH ITEM ICON: %s" % icon)
                params = dict(cItem)
                params.update({
                    'good_for_fav': True,
                    'title': title,
                    'url': url,
                    'icon': icon,
                    'desc': item.get('year', '') + ' | ' + item.get('ribbon', ''),
                    'category': 'explore_items',
                    'type': 'category',
                })
                self.addDir(params)
        except Exception:
            printExc()
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('WeCima.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: >> name[%s], category[%s] " % (name, category))
        self.currList = []
        # MAIN MENU
        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'explore_items':
            self.exploreItems(self.currItem)
        elif category == 'movies_categories':
            self.listMoviesCategories(self.currItem)
        elif category == 'series_categories':
            self.listSeriesCategories(self.currItem)
        elif category == 'anime_categories':
            self.listAnimeCategories(self.currItem)
        elif category == 'other_categories':
            self.listOtherCategories(self.currItem)
        elif category == 'list_movies':
            self.listUnits(self.currItem)
        elif category == 'list_series':
            self.listUnits(self.currItem)
        elif category == 'list_anime':
            self.listUnits(self.currItem)
        elif category == 'list_other':
            self.listUnits(self.currItem)
        elif category == 'list_episodes':
            self.listEpisodes(self.currItem)
        # SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        # HISTORY SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)
class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, WeCima(), True, [])
    def withArticleContent(self, cItem):
        if 'video' == cItem.get('type', '') or 'explore_item' == cItem.get('category', ''):
            return True
        return False